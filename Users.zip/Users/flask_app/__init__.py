from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
app.secret_key = 'rootroot' # set a secret key for security purposes
# ...server.py
