
from flask_app import app
from flask import render_template,redirect,request,session,flash
from flask_app.models.user_model import Users

@app.route('/users')
def show():
    all_users=Users.get_all()
    print(all_users)

    return render_template("read.html", all_users=all_users)




@app.route('/new', methods=['POST'])
def create_new():

    data = {
        
        'first_name' : request.form['first_name'],
        'last_name' : request.form['last_name'],
        'email' : request.form['email'],
        
    }
    
    Users.add_user(data)

    print()
    return render_template('create.html')





@app.route("/users/new")
def create():

    return render_template("create.html")



@app.route('/show_user/<int:id>')
def show_user(id):
    one_user=Users.get_one({'id':id})
    print(one_user)
    return render_template("show_user.html", one_user=one_user)


@app.route('/edit_user/<int:id>')
def edit_users(id):
    one_user=Users.get_one({'id':id})
    return render_template('edit_user.html', one_user=one_user)



@app.route('/delete_user/<int:id>')
def delete_user(id):
    one_user=Users.delete_user({'id':id})
    
    return redirect('/users')


